#!/usr/bin/env python3
from __future__ import annotations

import argparse
from engine.revenue_rescue_engine import render_execution_document

def main():
    p = argparse.ArgumentParser(description="HubSpot Revenue Rescue — deterministic demo CLI")
    p.add_argument("--text", required=True, help="Input text describing revenue signals")
    args = p.parse_args()
    print(render_execution_document(args.text))

if __name__ == "__main__":
    main()
