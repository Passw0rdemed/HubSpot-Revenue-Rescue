"""
Deterministic demo engine for HubSpot Revenue Rescue.

- Parses simple revenue signals from free-form text
- Produces an execution-document output following the mandatory framework
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass
class ParsedSignals:
    inactive_mqls: Optional[int] = None
    avg_deal_size: Optional[float] = None
    close_rate: Optional[float] = None  # decimal, e.g. 0.12

    notes: str = ""


_MONEY_RE = re.compile(r"\$\s*([0-9][0-9,]*(?:\.[0-9]+)?)")
_INT_RE = re.compile(r"([0-9][0-9,]*)")
_PERCENT_RE = re.compile(r"([0-9]+(?:\.[0-9]+)?)\s*%")

def _to_int(s: str) -> int:
    return int(s.replace(",", "").strip())

def _to_float(s: str) -> float:
    return float(s.replace(",", "").strip())

def parse_signals(text: str) -> ParsedSignals:
    t = text.strip()

    inactive_mqls = None
    # patterns like "240 inactive MQLs", "Inactive MQLs: 240"
    m = re.search(r"(inactive\s+MQLs|Inactive\s+MQLs)\s*[:\-]?\s*([0-9][0-9,]*)", t, re.IGNORECASE)
    if m:
        inactive_mqls = _to_int(m.group(2))
    else:
        m2 = re.search(r"([0-9][0-9,]*)\s+inactive\s+MQLs", t, re.IGNORECASE)
        if m2:
            inactive_mqls = _to_int(m2.group(1))

    avg_deal_size = None
    # patterns like "Average deal size is $1,100" or "Avg deal size: $2000"
    m = re.search(r"(average|avg)\s+deal\s+size[^$]*\$\s*([0-9][0-9,]*(?:\.[0-9]+)?)", t, re.IGNORECASE)
    if m:
        avg_deal_size = _to_float(m.group(2))
    else:
        m2 = re.search(r"\$\s*([0-9][0-9,]*(?:\.[0-9]+)?)\s+(average|avg)\s+deal\s+size", t, re.IGNORECASE)
        if m2:
            avg_deal_size = _to_float(m2.group(1))

    close_rate = None
    m = re.search(r"(close\s+rate)[^0-9%]*([0-9]+(?:\.[0-9]+)?)\s*%", t, re.IGNORECASE)
    if m:
        close_rate = float(m.group(2)) / 100.0
    else:
        # allow "Close rate is 0.12"
        m2 = re.search(r"(close\s+rate)[^0-9]*([0-9]+(?:\.[0-9]+)?)", t, re.IGNORECASE)
        if m2:
            val = float(m2.group(2))
            close_rate = val if val <= 1 else val / 100.0

    notes = ""
    if inactive_mqls is None:
        notes += "Missing inactive MQL count. "
    if avg_deal_size is None:
        notes += "Missing average deal size. "
    if close_rate is None:
        notes += "Missing close rate. "
    return ParsedSignals(inactive_mqls=inactive_mqls, avg_deal_size=avg_deal_size, close_rate=close_rate, notes=notes.strip())


def compute_recoverable_revenue(signals: ParsedSignals) -> Tuple[Optional[float], str]:
    """
    Returns (recoverable_revenue, assumptions_note)
    """
    assumptions = []
    mqls = signals.inactive_mqls
    deal = signals.avg_deal_size
    rate = signals.close_rate

    # Conservative defaults ONLY for demo, and explicitly labeled.
    if mqls is None:
        assumptions.append("Assumed inactive MQLs = 200 (demo default).")
        mqls = 200
    if deal is None:
        assumptions.append("Assumed average deal size = $1,000 (demo default).")
        deal = 1000.0
    if rate is None:
        assumptions.append("Assumed close rate = 10% (demo default).")
        rate = 0.10

    recoverable = float(mqls) * float(deal) * float(rate)
    return recoverable, (" ".join(assumptions) if assumptions else "No assumptions. All inputs provided.")


def grade_performance(signals: ParsedSignals) -> Tuple[str, str]:
    """
    Simple grading heuristic for demo purposes.
    """
    # If many inactive MQLs, execution is failing.
    mqls = signals.inactive_mqls or 0
    if mqls >= 500:
        return "F", "Severe execution failure: high inactive MQL volume indicates broken SLA enforcement."
    if mqls >= 200:
        return "D", "Execution is drifting: inactive MQL volume is materially leaking revenue."
    if mqls >= 50:
        return "C", "Execution is inconsistent: leakage present, enforcement required."
    if mqls > 0:
        return "B", "Minor leakage detected: tighten SLA and automated reactivation."
    return "A", "No inactive MQL leakage indicated in the provided signal."


def build_workflow(signals: ParsedSignals) -> str:
    """
    HubSpot-ready workflow blueprint (generic but deployable).
    """
    return """Trigger:
- Contact property: last_activity_date is more than 30 days ago
- AND lifecycle_stage = MQL

Segment:
- Inactive MQLs (no sales activity within SLA window)

Conditions:
- If lead_owner is empty → assign to SDR queue
- If lead_owner exists → create task for owner

Tasks:
- Create task: \"Reactivate inactive MQL\" due in 1 business day
- If not completed in 48 hours → escalate to manager (internal notification)

Delays:
- Wait 2 days after first task
- Wait 5 days after sequence enrollment

Automated actions:
- Enroll in reactivation sequence
- Update property: revenue_rescue_status = \"Reactivation In Progress\"
- If engagement occurs (reply/click) → create follow-up task within 4 hours
"""


def build_email() -> str:
    return """Subject: Quick check-in — should we close the loop?

Hi {{first_name}},

You reached out recently and I want to make sure we didn’t drop the ball.  
If you’re still evaluating, I can suggest the next best step in 2 minutes.

Are you open to a quick call this week, or should I send a short summary by email?

Best,  
{{rep_name}}
"""


def render_execution_document(user_text: str) -> str:
    sig = parse_signals(user_text)
    recoverable, assumptions = compute_recoverable_revenue(sig)
    grade, justification = grade_performance(sig)

    status_lines = []
    if (sig.inactive_mqls or 0) > 0:
        status_lines.append(f"- Inactive MQLs detected: {sig.inactive_mqls if sig.inactive_mqls is not None else 'assumed'}")
    else:
        status_lines.append("- No inactive MQL volume provided; default diagnostic applied.")
    status_lines.append("- Primary failure mode: execution delay (SLA + follow-up enforcement).")

    doc = f"""🚨 Status Report
{chr(10).join(status_lines)}

💰 Potential Loss Calculator
- Recoverable Revenue (simple model) = Inactive_MQLs × Avg_Deal_Size × Close_Rate
- Estimated Recoverable Revenue: ${recoverable:,.0f}
- Assumptions: {assumptions}

🛠 HubSpot Rescue Workflow
{build_workflow(sig)}

📧 Email Template
{build_email()}

📊 Performance Grade
- Grade: {grade}
- Reason: {justification}
"""
    return doc
