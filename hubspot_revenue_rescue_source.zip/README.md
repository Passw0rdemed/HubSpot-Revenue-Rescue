# HubSpot Revenue Rescue — No-Nonsense Growth Director (Source Package)

This repository contains a **judge-ready** source package for the “HubSpot Revenue Rescue” concept:
- Deterministic decision logic (offline) that turns revenue signals into **execution documents**
- A browser-based demo UI (no backend required)
- A Python CLI for repeatable outputs
- Locked output framework aligned to the hackathon submission

> Note: This is an **offline deterministic demo** intended for hackathon evaluation. It does not call HubSpot APIs by default.

---

## What’s Included

- `prompts/` — System prompt + output framework (for Agent.ai or any LLM wrapper)
- `engine/` — Deterministic parsing and calculations (Python + JS)
- `web_demo/` — One-file web UI demo (open in browser)
- `examples/` — Example inputs + expected outputs
- `docs/` — Architecture notes and operating modes

---

## Quick Start (Web Demo)

1. Open `web_demo/index.html` in Chrome.
2. Paste:
   `We have 240 inactive MQLs. Average deal size is $1,100. Close rate is 12%.`
3. Click **Generate Execution Output**.

---

## Quick Start (Python CLI)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python engine/revenue_rescue_cli.py --text "We have 240 inactive MQLs. Average deal size is $1,100. Close rate is 12%."
```

---

## Output Contract (Mandatory Framework)

Every output contains:
- 🚨 Status Report
- 💰 Potential Loss Calculator
- 🛠 HubSpot Rescue Workflow
- 📧 Email Template
- 📊 Performance Grade

See `prompts/output_framework.md`.

---

## License

MIT (see `LICENSE`).
