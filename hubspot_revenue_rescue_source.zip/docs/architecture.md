# System Architecture (Demo Package)

## Agent Type
- Knowledge Agent (not a workflow agent)
- Deterministic logic behind the scenes
- Executive-facing outputs

## Layers
1) Messaging Layer
   - Strong welcome message
   - Action-oriented prompt suggestions
2) Executive Behavior Layer
   - CRO tone enforcement
   - Prevent assistant-like behavior
3) Decision Logic Layer
   - Deterministic parsing + structured outputs
   - Multi-operating modes

## Multi-Operating Modes (Concept)
- Revenue Leak Detection Mode
- Recovery Workflow Builder Mode
- Email Playbook Mode
- Webhook Simulation Mode
- Strict Judge Mode
